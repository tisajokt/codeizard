package com.example.codeizard;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.github.nkzawa.socketio.client.IO;
import com.github.nkzawa.socketio.client.Socket;
import com.github.nkzawa.emitter.Emitter;



import java.net.URISyntaxException;

public class MainActivity extends AppCompatActivity {
    public String update = "";
    private Socket mSocket;
    {
        try {
            mSocket = IO.socket("https://codeizard.herokuapp.com/"); //change to url to go to
        } catch (URISyntaxException e) {}
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //mSocket.emit("me", "stuff");
        mSocket.on("notif", onNewMessage);
        mSocket.connect();
    }

    private Emitter.Listener onNewMessage = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {

                    String data = (String) args[0];
                    String message;
                    message = data;
                    setText(message);
                    // add the message to view
                    System.out.print("debug in call");
                }

        };

        public void setText(String message){
            TextView textView = findViewById(R.id.textView);
            textView.setText("There is pollen today");
        }
    }


